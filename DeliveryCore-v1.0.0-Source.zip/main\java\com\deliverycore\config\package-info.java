/**
 * Configuration management package for DeliveryCore.
 * Contains configuration interfaces and implementations for
 * categories, deliveries, and language files.
 */
package com.deliverycore.config;
