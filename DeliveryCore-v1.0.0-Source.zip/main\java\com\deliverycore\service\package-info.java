/**
 * Service layer package for DeliveryCore.
 * Contains business logic services for categories, deliveries,
 * scheduling, rewards, and messaging.
 */
package com.deliverycore.service;
