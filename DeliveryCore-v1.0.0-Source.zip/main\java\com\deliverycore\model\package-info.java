/**
 * Data model package for DeliveryCore.
 * Contains record classes and enums representing
 * categories, deliveries, winners, and configuration data.
 */
package com.deliverycore.model;
